﻿using System;
using System.Data.SqlClient;
using System.Web;

namespace romit
{
    public partial class Logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetNoStore();
                Response.Cache.SetExpires(DateTime.Now);
                Response.Cache.SetValidUntilExpires(true);
                Response.Redirect("Login.aspx");
            

        }
    }
}