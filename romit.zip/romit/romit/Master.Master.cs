﻿using System;
using System.Data.SqlClient;

namespace romit
{
    public partial class WebForm2 : System.Web.UI.MasterPage
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            GetTotalCustomers();
        }
        public void GetTotalCustomers()
        {
            string Userid = (String)Session["Uid"];
            //int totalCustomers, totalProducts = 0;

            //SqlCommand cmd = new SqlCommand("SELECT count(total) FROM tblCart WHERE customerid=@customerid", connectionString);
            //cmd.Parameters.AddWithValue("@customerid", Userid);
            //connectionString.Open();
            //object result = cmd.ExecuteScalar();

            //if (result != DBNull.Value)
            //{
            //    totalCustomers = Convert.ToInt32(result);
            //}
            //else
            //{
            //    totalCustomers = 0;
            //}

            //Label2.Text = totalCustomers.ToString();

            if(Userid != null)
            {
                int totalCustomers, totalProducts = 0;

                SqlCommand cmd = new SqlCommand("SELECT count(total) FROM tblCart WHERE customerid=@customerid", connectionString);
                cmd.Parameters.AddWithValue("@customerid", Userid);
                connectionString.Open();
                object result = cmd.ExecuteScalar();

                if (result != DBNull.Value)
                {
                    totalCustomers = Convert.ToInt32(result);
                }
                else
                {
                    totalCustomers = 0;
                }

                Label2.Text = totalCustomers.ToString();
            }


            connectionString.Close();
        }
    }
}