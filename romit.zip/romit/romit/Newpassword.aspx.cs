﻿using System;
using System.Data.SqlClient;
using System.Text;

namespace romit
{
    public partial class Newpassword : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void savesubmit_Click(object sender, EventArgs e)
        {
            string userName = (String)Session["username"];
            String email = (String)Session["email"];

            string customer_password = encryptpass(newpassworduser.Text);

            if (newpassworduser.Text != cnfnewpassworduser.Text)
            {
                errpasswordmatch.Text = "Password and Confirm Password doesn't match";
            }
            else
            {


                String ins = "UPDATE tblUser SET password = '"+ customer_password + "' WHERE email = '" + email + "'";
                connectionString.Open();
                SqlCommand cmd = new SqlCommand(ins, connectionString);
                //cmd.Parameters.AddWithValue("@customer_password", customer_password);
                //cmd.Parameters.AddWithValue("@userName", email);
                cmd.ExecuteNonQuery();
                connectionString.Close();
                Response.Redirect("Login.aspx");

          

            }
        }
        public string encryptpass(string password)
        {
            string msg = "";
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            msg = Convert.ToBase64String(encode);
            return msg;
        }
    }
}