﻿using System;
using System.Net.Mail;

namespace romit
{
    public partial class ContactUs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text.Trim();
            string email = TextBox2.Text.Trim();
            string subject = TextBox3.Text.Trim();
            string message = TextBox4.Text.Trim();




            // Create and configure a new MailMessage
            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(email);
            mail.To.Add("romitdobariya01@gmail.com");
            mail.Subject = subject;

            // Create the HTML body of the message
            string body = "<html><head><style>" +
            "body { background-color: #f2f2f2; font-family: Arial, sans-serif; }" +
            "h2 { color: #333; text-align: center; }" +
            ".message-box { background-color: #fff; border-radius: 5px; box-shadow: 0 0 5px #ccc; margin: 20px auto; padding: 20px; width: 80%; }" +
            ".btn { background-color: #4CAF50; border: none; border-radius: 3px; color: #fff; cursor: pointer; display: inline-block; font-size: 16px; margin-top: 20px; padding: 10px 20px; text-decoration: none; text-align: center; }" +
            ".btn:hover { background-color: #3e8e41; }" +
            "@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }" +
            ".success-message { animation-name: fadeOut; animation-duration: 3s; animation-fill-mode: forwards; opacity: 1; text-align: center; }" +
            "</style></head><body>" +
            "<div class=\"message-box\">" +
            "<h2>Contact Us</h2>" +
            "<p><strong>Name:</strong> " + name + "</p>" +
            "<p><strong>Email:</strong> " + email + "</p>" +
            "<p><strong>Subject:</strong> " + subject + "</p>" +
            "<p><strong>Message:</strong></p><p>" + message + "</p>" +
            "</div>" +
            "<div class=\"success-message\">" +
            "<p>Your message has been sent. We will get back to you soon.</p>" +
            "</div>" +
            "<script>" +
            "setTimeout(function() { document.querySelector('.success-message').style.display = 'none'; }, 3000);" +
            "</script>" +
            "</body></html>";

            mail.Body = body;
            mail.IsBodyHtml = true;

            // Create and configure a new SmtpClient
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com"; // Replace with your SMTP server hostname
            smtp.Port = 587; // Replace with your SMTP server port number
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("romitdobariya01@gmail.com", "ljmnvzsbjgopizuv"); // Replace with your email address and password
            smtp.EnableSsl = true;

            // Send the message
            smtp.Send(mail);

            // Clear form fields
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";

            // Show success message
            Response.Write("<script>alert('Your message has been sent. We will get back to you soon.')</script>");
        }
    }
    
}