﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace romit
{
    public partial class minus : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request.QueryString["id"];
            string quantity = Request.QueryString["quantity"];
            string total = Request.QueryString["Ptotal"];
            int quantityInt = int.Parse(quantity);
            if (quantityInt >= 2)
            {

                quantityInt -= 1;

                int totalNew = int.Parse(total);
                int updatedTotal = quantityInt * totalNew;
                string totalStr = updatedTotal.ToString();
                string quantityStr = quantityInt.ToString();
                string query = "UPDATE tblCart SET quantity = @quantity, total = @total WHERE cartid = @cartid";
                SqlCommand command = new SqlCommand(query, connectionString);
                command.Parameters.AddWithValue("@quantity", quantityStr);
                command.Parameters.AddWithValue("@total", totalStr);
                command.Parameters.AddWithValue("@cartid", id);

                connectionString.Open();
                command.ExecuteNonQuery();
                Response.Redirect("cart.aspx");
            }
            else
            {

                Response.Redirect("cart.aspx");
                ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Minimum quantity should be 1.');", true);
            }
        }
    }
}