﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace romit
{
    public partial class Home : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");


        protected void Page_Load(object sender, EventArgs e)
        {

            //SqlConnection conn = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
            //conn.Open();
            //SqlCommand cmd = new SqlCommand("select * from tblCategorys", conn);
            //SqlDataReader dr = cmd.ExecuteReader();
            //if (dr.HasRows == true)
            //{
            //    DataList1.DataSource = dr;
            //    DataList1.DataBind();
            //}

            if (!IsPostBack)
            {
                SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");


                using (connectionString)
                {
                    SqlCommand command = new SqlCommand("SELECT * FROM tblCategorys", connectionString);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    rptCategories.DataSource = table;
                    rptCategories.DataBind();

                    SqlCommand command1 = new SqlCommand("SELECT * FROM tblProduct", connectionString);

                    SqlDataAdapter adapter1 = new SqlDataAdapter(command1);
                    DataTable table1 = new DataTable();
                    adapter1.Fill(table1);

                    rptProduct.DataSource = table1;
                    rptProduct.DataBind();


                }

                //using (connectionString)
                //{
                //    SqlCommand command = new SqlCommand("SELECT * FROM tblProduct", connectionString);

                //    SqlDataAdapter adapter = new SqlDataAdapter(command);
                //    DataTable table = new DataTable();
                //    adapter.Fill(table);

                //    rptProduct.DataSource = table;
                //    rptProduct.DataBind();
                //}
            }

            string name = (String)Session["username"];
            if (Session["username"] != null)
            {
                Label1.Text = name;
            }


        }




    }
}