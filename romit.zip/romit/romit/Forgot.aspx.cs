﻿using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace romit
{
    public partial class Forgot : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void otpgetButton_Click(object sender, EventArgs e)
        {
            string email = emailTextBox.Text;

            string query = "SELECT COUNT(1) FROM tblUser WHERE email=@email";

            using (connectionString)
            {
                connectionString.Open();
                SqlCommand cmd = new SqlCommand(query, connectionString);
                cmd.Parameters.AddWithValue("@email", email);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    string OTP = GenerateOTP();
                    SendEmail(email, OTP);
                    Session["OTP"] = OTP;
                    Session["email"] = email;
                    Response.Redirect("Otp.aspx");
                }
                else
                {
                    emailerr.Text = "Email not found.";
                }
            }
        }
        private string GenerateOTP()
        {
            string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            string OTP = string.Empty;
            for (int i = 0; i < 6; i++)
            {
                OTP += characters[random.Next(characters.Length)];
            }
            return OTP;
        }

        private void SendEmail(string email, string OTP)
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("romitdobariya01@gmail.com");
            mail.To.Add(email);
            mail.Subject = "Forgot Password OTP";
            mail.Body = "Your OTP is: " + OTP;
            SmtpServer.Port = 587;
            SmtpServer.UseDefaultCredentials = false;
            SmtpServer.Credentials = new NetworkCredential("romitdobariya01@gmail.com", "ljmn vzsb jgop izuv");
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);
        }
    }
}