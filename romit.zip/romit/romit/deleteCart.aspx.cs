﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace romit
{
    public partial class deleteCart : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request.QueryString["id"];
            string query = "DELETE FROM tblCart WHERE cartid = @cartid";
            SqlCommand command = new SqlCommand(query, connectionString);
            command.Parameters.AddWithValue("@cartid", id);

            connectionString.Open();
            command.ExecuteNonQuery();
            Response.Redirect("Cart.aspx");
        }
    }
}