﻿using System;
using System.Data.SqlClient;
using System.Text;

namespace romit
{
    public partial class Registration_verify : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        private DateTime otpExpiration;
        protected void Page_Load(object sender, EventArgs e)
        {



        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            

            otpExpiration = DateTime.Now.AddSeconds(5);
            string otp = (String)Session["regOTP"];
            string username = (String)Session["txtname"];
            string useremail = (String)Session["txtemail"];
            string userphone = (String)Session["txtnum"];
            string userpassword = (String)Session["txtpass"];
            string pwd = encryptpass(userpassword);

            var timenew = DateTime.Now;

            var old = DateTime.Parse(Session["time"].ToString());

            if (timenew.Subtract(old) >= TimeSpan.FromMinutes(1))
            {
                errotpexpire.Text = "The OTP Will remain 1 minute only";
            }
            else
            {

                if (otp == otpreg.Text)
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into tblUser (name,email,phone,password) Values('" + username + "','" + useremail + "','" + userphone + "','" + pwd + "')", con);
                    cmd.ExecuteNonQuery();
                    //Response.Write("<script> alert('Registration Successfully done'); </script>");
                    con.Close();
                    Response.Redirect("Login.aspx");
                }
                else
                {
                    otpwrong.Text = "Your Otp Is Invalid";
                }

            }




        }
        public string encryptpass(string password)
        {
            string msg = "";
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            msg = Convert.ToBase64String(encode);
            return msg;
        }

    }
}