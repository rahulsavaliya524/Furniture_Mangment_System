﻿using System;

namespace romit
{
    public partial class Otp : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string otp = (String)Session["OTP"];

            if (otp == otpTextBox.Text)
            {

                Response.Redirect("Newpassword.aspx");
            }
            else
            {
                otperre.Text = "please enter valid otp";
            }

        }

    }
}