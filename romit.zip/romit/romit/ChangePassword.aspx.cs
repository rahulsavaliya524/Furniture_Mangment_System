﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace romit
{

    public partial class ChangePassword : System.Web.UI.Page
    {
        SqlConnection con  = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void pedChange_Click(object sender, EventArgs e)
        {
           
            string pass1 = encryptpass(cOldPassword.Text);
            string pass2 = encryptpass(cNewPassword.Text);
            string pass3 = encryptpass(cCnfPassword.Text);
            string mail = (string)Session["username"];
            con.Open();
            string query = "select * from tblUser where email='" + mail + "' and password='" + pass1 + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                con.Close();
                string query1 = "UPDATE tblUser SET password = '" + pass2 + "' WHERE email = '" + mail + "'";
                SqlCommand cmd1 = new SqlCommand(query1, con);
                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                con.Close();

                Response.Write("<script>alert('new password and confirm password not match')</script>");
            }


        }
        public string encryptpass(string password)
        {
            string msg = "";
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            msg = Convert.ToBase64String(encode);
            return msg;
        }
    }
}