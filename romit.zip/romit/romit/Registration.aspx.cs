﻿using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace romit
{
    public partial class Registration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //private DateTime otpExpiration;

        protected void Button1_Click(object sender, EventArgs e)
        {

            string email = remail.Text;

            string query = "SELECT COUNT(1) FROM tblUser WHERE email=@email";

            using (connectionString)
            {
                connectionString.Open();
                SqlCommand cmd = new SqlCommand(query, connectionString);
                cmd.Parameters.AddWithValue("@email", email);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    emailerre.Text = "User is already registered.";


                }
                else

                {

                    string OTP = GenerateOTP();
                    SendEmail(email, OTP);
                    Session["regOTP"] = OTP;
                    Session["txtname"] = name.Text;
                    Session["txtemail"] = remail.Text;
                    Session["txtnum"] = phone.Text;
                    Session["txtpass"] = password.Text;

                    Session["email"] = email;

                    //otpExpiration = DateTime.Now.AddSeconds(5);

                    Response.Redirect("Registration_verify.aspx");
                }
            }

        }


        private string GenerateOTP()
        {
            string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            string OTP = string.Empty;
            for (int i = 0; i < 6; i++)
            {
                OTP += characters[random.Next(characters.Length)];
            }
            return OTP;
        }

        private void SendEmail(string email, string OTP)
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("romitdobariya01@gmail.com");
            mail.To.Add(email);
            mail.Subject = "Forgot Password OTP";
            mail.Body = "Your OTP is: " + OTP;
            SmtpServer.Port = 587;
            SmtpServer.UseDefaultCredentials = false;
            SmtpServer.Credentials = new NetworkCredential("romitdobariya01@gmail.com", "ljmn vzsb jgop izuv");
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);

            Session["time"] = DateTime.Now;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }
    }
}