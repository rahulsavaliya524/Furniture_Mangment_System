﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace romit
{
    public partial class payment_gateway : System.Web.UI.Page
    {
        public decimal a;
        public int amount;
        protected void Page_Load(object sender, EventArgs e)
        {
            string totalAmount = (string)Session["totalamount"].ToString();
            a = Convert.ToDecimal(totalAmount) * 100;
        }
    }
}