﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace romit
{
    public partial class Cart : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["username"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            string Userid = (String)Session["Uid"];

           

            if (!IsPostBack)
            {
                GetTotalCustomers();

                string id = Request.QueryString["id"];

                string product_price = "";
                if (id == null)
                {
                    string queryyy = "SELECT tblProduct.pname, tblProduct.vimage,tblCart.cartid,tblCart.Ptotal, tblCart.quantity, tblCart.total FROM tblCart INNER JOIN tblProduct ON tblCart.productid = tblProduct.pid WHERE tblCart.customerid = @customerid";

                    SqlCommand command = new SqlCommand(queryyy, connectionString);
                    command.Parameters.AddWithValue("@customerid", Userid);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    GridView1.DataSource = dt;
                    GridView1.DataBind();


                    HyperLinkField editColumn = new HyperLinkField();
                    HyperLinkField deleteColumn = new HyperLinkField();
                    HyperLinkField deleteGridColumn = new HyperLinkField();
                    deleteGridColumn.HeaderText = "Delete";
                    deleteGridColumn.Text = "Delete";
                    deleteGridColumn.DataNavigateUrlFormatString = "~/deleteCart.aspx?id={0}";
                    deleteGridColumn.DataNavigateUrlFields = new string[] { "cartid" };

                    deleteColumn.HeaderText = "Plus";
                    deleteColumn.Text = "+";
                    deleteColumn.DataNavigateUrlFormatString = "~/plus.aspx?id={0}&quantity={1}&total={2}&Ptotal={3}";
                    deleteColumn.DataNavigateUrlFields = new string[] { "cartid", "quantity", "total", "Ptotal" };

                    editColumn.HeaderText = "Minus";
                    editColumn.Text = "-";
                    editColumn.DataNavigateUrlFormatString = "~/minus.aspx?id={0}&quantity={1}&total={2}&Ptotal={3}";
                    editColumn.DataNavigateUrlFields = new string[] { "cartid", "quantity", "total", "Ptotal" };

                    GridView1.Columns.Add(editColumn);
                    GridView1.Columns.Add(deleteColumn);
                    GridView1.Columns.Add(deleteGridColumn);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {

                    string queryy = "SELECT price FROM tblProduct WHERE pid = @productId";
                    connectionString.Close();
                    connectionString.Open();
                    SqlCommand cmdd = new SqlCommand(queryy, connectionString); 
                    cmdd.Parameters.AddWithValue("@productId", id);

                    SqlDataReader reader = cmdd.ExecuteReader();
                    if (reader.Read())
                    {
                        product_price = reader["price"].ToString();
                    }
                    connectionString.Close();

                    string productidd = "SELECT productid FROM tblCart WHERE customerid = @productId";
                    string prid = "";
                    connectionString.Open();
                    SqlCommand cmdpr = new SqlCommand(productidd, connectionString);
                    cmdpr.Parameters.AddWithValue("@productId", Userid);

                    SqlDataReader readerr = cmdpr.ExecuteReader();
                    if (readerr.Read())
                    {
                        prid = readerr["productid"].ToString();
                    }
                    readerr.Close();
                    connectionString.Close();

                    if (!prid.Equals(id))
                    {
                        string query = "INSERT INTO tblCart(customerid,productid,quantity,total,Ptotal) VALUES(@customerid,@productid,@quantity,@total,@Ptotal)";
                        SqlCommand cmd = new SqlCommand(query, connectionString);

                        cmd.Parameters.AddWithValue("@customerid", Userid);
                        cmd.Parameters.AddWithValue("@productid", id);
                        cmd.Parameters.AddWithValue("@quantity", 1);
                        cmd.Parameters.AddWithValue("@total", product_price);
                        cmd.Parameters.AddWithValue("@Ptotal", product_price);

                        connectionString.Open();
                        cmd.ExecuteNonQuery();
                        connectionString.Close();


                        string queryyy = "SELECT tblProduct.pname, tblProduct.vimage, tblCart.quantity, tblCart.cartid, tblCart.total FROM tblCart INNER JOIN tblProduct ON tblCart.productid = tblProduct.pid WHERE tblCart.customerid = @customerid";

                        SqlCommand command = new SqlCommand(queryyy, connectionString);
                        command.Parameters.AddWithValue("@customerid", Userid);
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();



                        HyperLinkField editColumn = new HyperLinkField();
                        HyperLinkField deleteColumn = new HyperLinkField();
                        HyperLinkField deleteGridColumn = new HyperLinkField();
                        deleteGridColumn.HeaderText = "Delete";
                        deleteGridColumn.Text = "Delete";
                        deleteGridColumn.DataNavigateUrlFormatString = "~/deleteCart.aspx?id={0}";
                        deleteGridColumn.DataNavigateUrlFields = new string[] { "cartid" };

                        deleteColumn.HeaderText = "Plus";
                        deleteColumn.Text = "+";
                        deleteColumn.DataNavigateUrlFormatString = "~/plus.aspx?id={0}&quantity={1}&total={2}";
                        deleteColumn.DataNavigateUrlFields = new string[] { "cartid", "quantity", "total" };

                        editColumn.HeaderText = "Minus";
                        editColumn.Text = "-";
                        editColumn.DataNavigateUrlFormatString = "~/minus.aspx?id={0}&quantity={1}&total={2}";
                        editColumn.DataNavigateUrlFields = new string[] { "cartid", "quantity", "total" };

                        GridView1.Columns.Add(editColumn);
                        GridView1.Columns.Add(deleteColumn);
                        GridView1.Columns.Add(deleteGridColumn);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                    else
                    {
                        //string pidd = Request.QueryString["id"];

                        string qunaityUpdate = "SELECT quantity,Ptotal FROM tblCart WHERE customerid = @productId";
                        string q = "";
                        string totall = "";
                        //string i = "1019";

                        connectionString.Open();
                        SqlCommand qcmd = new SqlCommand(qunaityUpdate, connectionString);
                        qcmd.Parameters.AddWithValue("@productId", Userid);

                        SqlDataReader qreader = qcmd.ExecuteReader();
                        if (qreader.Read())
                        {
                            q = qreader["quantity"].ToString();
                            totall = qreader["Ptotal"].ToString();
                            int quantityInt = int.Parse(q);
                            int totalnew = int.Parse(totall);
                            totalnew = quantityInt * totalnew;
                            quantityInt += 1;
                            q = quantityInt.ToString();
                            totall = totalnew.ToString();
                        }
                        connectionString.Close();

                        string query = "UPDATE tblCart SET quantity = @quantity, total = @total WHERE productid = @cartid";
                        SqlCommand command = new SqlCommand(query, connectionString);
                        command.Parameters.AddWithValue("@quantity", q);
                        command.Parameters.AddWithValue("@total", totall);
                        command.Parameters.AddWithValue("@cartid", id);
                        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Product Already Exists.');", true);
                        connectionString.Open();
                        command.ExecuteNonQuery();
                        Response.Redirect("Cart.aspx");

                    }

                }

            }

        }
        //public void GetTotalCustomers()
        //{
        //    string Userid = (String)Session["Uid"];
        //    int totalCustomers, totalProducts = 0;

        //    SqlCommand cmd = new SqlCommand("SELECT SUM(total) FROM tblCart WHERE customerid=@customerid", connectionString);
        //    cmd.Parameters.AddWithValue("@customerid", Userid);
        //    connectionString.Open();
        //    //totalCustomers = (int)cmd.ExecuteScalar();
        //    object result = cmd.ExecuteScalar();
        //    if (result != null)
        //    {
        //        totalCustomers = (int?)result ?? 0;
        //    }
        //    else
        //    {
        //        totalCustomers = 0;
        //    }
        //    subtotalLabel.Text = totalCustomers.ToString();
        //    Label1.Text = totalCustomers.ToString();
        //}

        public void GetTotalCustomers()
        {
            string Userid = (String)Session["Uid"];
            int totalCustomers, totalProducts = 0;

            SqlCommand cmd = new SqlCommand("SELECT SUM(total) FROM tblCart WHERE customerid=@customerid", connectionString);
            cmd.Parameters.AddWithValue("@customerid", Userid);
            connectionString.Open();
            object result = cmd.ExecuteScalar();

            if (result != DBNull.Value)
            {
                totalCustomers = Convert.ToInt32(result);
            }
            else
            {
                totalCustomers = 0;
            }

            subtotalLabel.Text = totalCustomers.ToString();
            Label1.Text = totalCustomers.ToString();

            connectionString.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Checkout.aspx");
        }
    }
}