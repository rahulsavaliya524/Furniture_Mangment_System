﻿using System;
using System.Data.SqlClient;

namespace romit
{
    public partial class profile : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            if (!this.IsPostBack)
            {
                string UserEmail = (String)Session["username"];

                connectionString.Open();
                String query = "select * from tblUser where email = '" + UserEmail + "'";
                SqlCommand cmd = new SqlCommand(query, connectionString);
                SqlDataReader sdr = cmd.ExecuteReader();


                if (sdr.Read())
                {
                    Session["Uid"] = sdr["id"].ToString();
                    cusname.Text = sdr["name"].ToString();
                    cusemail.Text = sdr["email"].ToString();
                    cusphone.Text = sdr["phone"].ToString();
                    cuspincode.Text = sdr["pincode"].ToString();
                    cusaddress.Text = sdr["address"].ToString();
                }
                else
                {
                    Response.Redirect("index.aspx");
                }
                connectionString.Close();
            }

            //string UserEmail = (String)Session["username"];
            //connectionString.Open();
            //using (var command = new SqlCommand("SELECT * FROM tblUser WHERE email = @UserId", connectionString))
            //{
            //    command.Parameters.AddWithValue("@UserId", UserEmail); // Replace this with the actual user ID
            //    using (var reader = command.ExecuteReader())
            //    {
            //        if (reader.Read())
            //        {
            //            cusname.Text = reader["name"].ToString();
            //            cusemail.Text = reader["email"].ToString();
            //            cusphone.Text = reader["phone"].ToString();
            //            cusaddress.Text = reader["address"].ToString();
            //            cuspincode.Text = reader["pincode"].ToString();
            //            Session["welcomename"] = cusname.Text;
            //        }


            //    }
            //}
            //connectionString.Close();
        }

        protected void Chngepwd_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {


        }

        protected void updatebtn_Click1(object sender, EventArgs e)
        {


            Response.Redirect("ChangePassword.aspx");
        }

        protected void detail_Click(object sender, EventArgs e)
        {
            //connectionString.Open();

            //SqlCommand cmd = new SqlCommand("UPDATE tblUser SET name = '" + cusname.Text + "',address = '" + cusaddress.Text + "',pincode = '" + cuspincode.Text + "',phone = '" + cusphone.Text + "' WHERE email = '" + cusemail.Text + "'", connectionString);
            //cmd.ExecuteNonQuery();
            //connectionString.Close();

            string UserEmail = (String)Session["username"];


            connectionString.Open();
            String up = "update tblUser SET name=@name, address=@address, pincode=@pincode, phone=@num WHERE email=@email";
            SqlCommand cmd1 = new SqlCommand(up, connectionString);

            cmd1.Parameters.AddWithValue("@name", cusname.Text);
            cmd1.Parameters.AddWithValue("@num", cusphone.Text);
            cmd1.Parameters.AddWithValue("@pincode", cuspincode.Text);
            cmd1.Parameters.AddWithValue("@address", cusaddress.Text);
            cmd1.Parameters.AddWithValue("@email", UserEmail);

            cmd1.ExecuteNonQuery();
            cmd1.Dispose();
            connectionString.Close();



        }

        protected void updatevalue(object sender, EventArgs e)
        {
            connectionString.Open();

            SqlCommand cmd = new SqlCommand("update tblUser set name='" + cusname.Text + "',address='" + cusaddress.Text + "',pincode='" + cuspincode.Text + "',phone='" + cusphone.Text + "' WHERE email='" + cusemail.Text + "'", connectionString);
            cmd.ExecuteNonQuery();
            connectionString.Close();

         }

    }
}