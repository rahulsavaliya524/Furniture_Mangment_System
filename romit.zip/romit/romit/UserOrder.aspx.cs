﻿using System;

namespace romit
{
    public partial class UserOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (System.Web.HttpContext.Current.Session["username"] != null) {

            }else
            { 
                Response.Redirect("Login.aspx");
            
            }
        }
    }
}