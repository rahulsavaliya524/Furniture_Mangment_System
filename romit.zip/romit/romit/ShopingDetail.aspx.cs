﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace romit
{
    public partial class ShopingDetail : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string id = Request.QueryString["id"];

                using (connectionString)
                {
                    SqlCommand command = new SqlCommand("SELECT * FROM tblProduct WHERE pid=@id", connectionString);
                    command.Parameters.AddWithValue("@id", id);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    rptProducts.DataSource = table;
                    rptProducts.DataBind();

                    Repeater1.DataSource = table;
                    Repeater1.DataBind();




                }
            }
        }
    }
}