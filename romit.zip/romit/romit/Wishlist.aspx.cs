﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace romit
{
    public partial class Wishlist : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            string Userid = (String)Session["Uid"];

            if (Session["username"] == null)
            {
                Response.Redirect("login.aspx");
            }


            if (!IsPostBack)
            {
                string id = Request.QueryString["id"];


                if (id == null)
                {
                    string queryyy = "SELECT tblProduct.pname, tblProduct.vimage,tblwishlist.wid FROM tblwishlist INNER JOIN tblProduct ON tblwishlist.productid = tblProduct.pid WHERE tblwishlist.customerid = @customerid";

                    SqlCommand command = new SqlCommand(queryyy, connectionString);
                    command.Parameters.AddWithValue("@customerid", Userid);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    GridView1.DataSource = dt;
                    GridView1.DataBind();


                    HyperLinkField deleteGridColumn = new HyperLinkField();
                    deleteGridColumn.HeaderText = "Delete";
                    deleteGridColumn.Text = "Delete";
                    deleteGridColumn.DataNavigateUrlFormatString = "~/deletewishlist.aspx?id={0}";
                    deleteGridColumn.DataNavigateUrlFields = new string[] { "wid" };
                    
                    GridView1.Columns.Add(deleteGridColumn);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {

                    //string queryy = "SELECT Product_Price FROM tblProduct WHERE Product_id = @productId";
                    //connectionString.Close();
                    //connectionString.Open();
                    //SqlCommand cmdd = new SqlCommand(queryy, connectionString);
                    //cmdd.Parameters.AddWithValue("@productId", id);

                    //SqlDataReader reader = cmdd.ExecuteReader();
                    //if (reader.Read())
                    //{
                    //    product_price = reader["Product_Price"].ToString();
                    //}
                    //connectionString.Close();

                    string productidd = "SELECT productid FROM tblwishlist WHERE customerid = @customerid";
                    string prid = "";
                    string cid = "";
                    connectionString.Open();
                    SqlCommand cmdpr = new SqlCommand(productidd, connectionString);
                    cmdpr.Parameters.AddWithValue("@customerid", Userid);

                    SqlDataReader readerr = cmdpr.ExecuteReader();
                    while (readerr.Read())
                    {

                        prid = readerr["productid"].ToString();

                    }
                    connectionString.Close();

                    if (!prid.Equals(id))
                    {
                        string query = "INSERT INTO tblwishlist(customerid,productid) VALUES(@customerid,@productid)";
                        SqlCommand cmd = new SqlCommand(query, connectionString);

                        cmd.Parameters.AddWithValue("@customerid", Userid);
                        cmd.Parameters.AddWithValue("@productid", id);

                        connectionString.Open();
                        cmd.ExecuteNonQuery();
                        connectionString.Close();


                        string queryyy = "SELECT tblProduct.pname, tblProduct.vimage, tblwishlist.wid FROM tblwishlist INNER JOIN tblProduct ON tblwishlist.productid = tblProduct.pid WHERE tblwishlist.customerid = @customerid";

                        SqlCommand command = new SqlCommand(queryyy, connectionString);
                        command.Parameters.AddWithValue("@customerid", Userid);
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();


                        HyperLinkField deleteGridColumn = new HyperLinkField();
                        deleteGridColumn.HeaderText = "Delete";
                        deleteGridColumn.Text = "Delete";
                        deleteGridColumn.DataNavigateUrlFormatString = "~/deletewishlist.aspx?id={0}";
                        deleteGridColumn.DataNavigateUrlFields = new string[] { "wid" };

                        GridView1.Columns.Add(deleteGridColumn);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }



                }
            }



        }

    }
    
}   