﻿using System;
using System.Data.SqlClient;
using System.Text;


namespace romit
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string username = emailTextBox.Text;
            //string password = passwordTextBox.Text;

            string lpwd = encryptpass(passwordTextBox.Text);

            connectionString.Open();
            string query = "select * from tblUser where email='" + username + "' and password='" + lpwd + "'";
            SqlCommand cmd = new SqlCommand(query, connectionString);
            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr.Read())
            {
                Session["username"] = username;
                Response.Redirect("Profile.aspx");

            }
            else
            {
                emailerre.Text = "Invalid Username or Password.";
            }
            connectionString.Close();
        }

        //string query = "SELECT COUNT(1) FROM tblUser WHERE email=@username AND password=@lpwd";
        //    using (connectionString)
        //    {
        //        connectionString.Open();
        //        SqlCommand cmd = new SqlCommand(query, connectionString);
        //        cmd.Parameters.AddWithValue("@username", username);
        //        cmd.Parameters.AddWithValue("@lpwd", password);

        //        int count = Convert.ToInt32(cmd.ExecuteScalar());
        //        if (count == 1)
        //        {


        //            Session["username"] = username;
        //            Response.Redirect("Profile.aspx");

        //        }
        //        else
        //        {
        //            emailerre.Text = "Invalid username or password.";
        //        }

        //    }
    

        public string encryptpass(string password)
        {
            string msg = "";
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            msg = Convert.ToBase64String(encode);
            return msg;
        }

    }
}