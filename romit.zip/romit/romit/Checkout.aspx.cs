﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace romit
{
    public partial class Checkout : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            if (!IsPostBack)
            {
                GetTotalCustomers();
            }
        }

        public void GetTotalCustomers()
        {
            string Userid = (String)Session["Uid"];
            int totalCustomers, totalProducts = 0;

            SqlCommand cmd = new SqlCommand("SELECT SUM(total) FROM tblCart WHERE customerid=@customerid", connectionString);
            cmd.Parameters.AddWithValue("@customerid", Userid);
            connectionString.Open();
            totalCustomers = (int)cmd.ExecuteScalar();

            subtotalLabel.Text = totalCustomers.ToString();
            Label1.Text = totalCustomers.ToString();
        }





        protected void Button1_Click(object sender, EventArgs e)
        {
            string Userid = (String)Session["Uid"];
            int totalCustomers, totalProducts = 0;

            SqlCommand cmdd = new SqlCommand("SELECT SUM(total) FROM tblCart WHERE customerid=@customerid", connectionString);
            cmdd.Parameters.AddWithValue("@customerid", Userid);
            connectionString.Open();
            totalCustomers = (int)cmdd.ExecuteScalar();

            Session["totalamount"] = totalCustomers.ToString();

            string query = "INSERT INTO tblOrder(customer_id,total_Amount,address,city,state,payment_mode,order_date) VALUES(@customerid,@totalAmount,@address,@city,@state,@paymentmode,@orderdate); SELECT SCOPE_IDENTITY()";
            SqlCommand cmd = new SqlCommand(query, connectionString);

            cmd.Parameters.AddWithValue("@customerid", Userid);
            cmd.Parameters.AddWithValue("@totalAmount", totalCustomers.ToString());
            cmd.Parameters.AddWithValue("@address", TextBox5.Text);
            cmd.Parameters.AddWithValue("@city", "Surat");
            cmd.Parameters.AddWithValue("@state", "Gujarat");
            cmd.Parameters.AddWithValue("@paymentmode", "COD");
            cmd.Parameters.AddWithValue("@orderdate", DateTime.Now);

            int orderId = Convert.ToInt32(cmd.ExecuteScalar());

            connectionString.Close();

            string cartQuery = "SELECT productid, quantity, total FROM tblCart WHERE customerid = @customerid";
            string orderItemQuery = "INSERT INTO tblOrderItems (order_id, product_id, quantity, product_price) VALUES (@orderid, @productid, @quantity, @price)";


            using (connectionString)
            {
                connectionString.Open();

                // Get cart data
                using (SqlCommand cartCommand = new SqlCommand(cartQuery, connectionString))
                {
                    cartCommand.Parameters.AddWithValue("@customerid", Userid);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cartCommand))
                    {
                        DataTable cartData = new DataTable();
                        adapter.Fill(cartData);

                        foreach (DataRow cartRow in cartData.Rows)
                        {
                            // Get values from cart data
                            int productId = Convert.ToInt32(cartRow["productid"]);
                            int quantity = Convert.ToInt32(cartRow["quantity"]);
                            int price = Convert.ToInt32(cartRow["total"]);

                            // Insert values into order table
                            using (SqlCommand orderItemCommand = new SqlCommand(orderItemQuery, connectionString))
                            {
                                orderItemCommand.Parameters.AddWithValue("@orderid", orderId);
                                orderItemCommand.Parameters.AddWithValue("@productid", productId);
                                orderItemCommand.Parameters.AddWithValue("@quantity", quantity);
                                orderItemCommand.Parameters.AddWithValue("@price", price);
                                orderItemCommand.ExecuteNonQuery();
                            }
                        }
                    }

                    // Delete cart data for customer
                    using (SqlCommand deleteCartCommand = new SqlCommand("DELETE FROM tblCart WHERE customerid = @customerid", connectionString))
                    {
                        deleteCartCommand.Parameters.AddWithValue("@customerid", Userid);
                        deleteCartCommand.ExecuteNonQuery();
                    }
                }

                connectionString.Close();
            }

            Response.Redirect("payment_gateway.aspx");

        }
    }
}