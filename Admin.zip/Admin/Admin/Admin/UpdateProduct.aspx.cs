﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class UpdateProduct : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                PopulateCategoryList();
                if (Request.QueryString["id"] != null)
                {
                    int id = int.Parse(Request.QueryString["id"]);
                    string query = "SELECT * FROM tblProduct WHERE pid=@Product_id";

                    using (connectionString)
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(query, connectionString))
                        {
                            adapter.SelectCommand.Parameters.AddWithValue("@Product_id", id);
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            if (dt.Rows.Count > 0)
                            {

                                pnametxt.Text = dt.Rows[0]["pname"].ToString();
                                pdesctxt.Text = dt.Rows[0]["disc"].ToString();

                                int categoryId = int.Parse(dt.Rows[0]["cid"].ToString());
                                category.SelectedValue = categoryId.ToString();

                                string imagePath = dt.Rows[0]["pimage"].ToString();
                                if (!string.IsNullOrEmpty(imagePath))
                                {
                                    product_imgupload.Attributes["value"] = imagePath;
                                }
                                product_quantity.Text = dt.Rows[0]["quantity"].ToString();
                                
                                product_price.Text = dt.Rows[0]["price"].ToString();

                            }
                        }

                    }
                }
            }
        }
        private void PopulateCategoryList()
        {
            string query = "SELECT * FROM tblCategorys";
            SqlCommand cmd = new SqlCommand(query, connectionString);
            connectionString.Open();
            SqlDataReader rreader = cmd.ExecuteReader();
            while (rreader.Read())
            {
                ListItem item = new ListItem();
                item.Text = rreader["cname"].ToString();
                item.Value = rreader["cid"].ToString();
                category.Items.Add(item);
            }
            rreader.Close();
            connectionString.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int id = int.Parse(Request.QueryString["id"]);
            string name = pnametxt.Text;
            string desc = pdesctxt.Text;
            int CategoryId = int.Parse(category.SelectedValue);

            int qty = int.Parse(product_quantity.Text);
            int price = int.Parse(product_price.Text);
           
           
            
            string fileName = Path.GetFileName(product_imgupload.FileName);
            string fileExtension = Path.GetExtension(fileName);

            // Create a unique file name to avoid overwriting existing files
            string uniqueFileName = Guid.NewGuid().ToString() + fileExtension;

            // Specify the directory to save the uploaded file
            string uploadDirectory = Server.MapPath("~/ProductImages/");

            // Save the uploaded file to the specified directory
            product_imgupload.SaveAs(uploadDirectory + uniqueFileName);

            // Get the file path
            string filePath = "Productimages/" + uniqueFileName;

            string query = "UPDATE tblProduct SET pname = @Product_name,cid = @Category_id,quantity = @Product_qty,pimage = @Product_imge,price = @Product_Price,disc = @Product_desc WHERE pid = @id";
            SqlCommand cmd = new SqlCommand(query, connectionString);

            cmd.Parameters.AddWithValue("@Product_name", name);
            cmd.Parameters.AddWithValue("@Category_id", CategoryId);
            cmd.Parameters.AddWithValue("@Product_qty", qty);
            cmd.Parameters.AddWithValue("@Product_imge", filePath);
            cmd.Parameters.AddWithValue("@Product_Price", price);
            cmd.Parameters.AddWithValue("@Product_desc", desc);
            cmd.Parameters.AddWithValue("@id", id);
            connectionString.Open();
            cmd.ExecuteNonQuery();
            connectionString.Close();

            Response.Redirect("viewproduct.aspx");
        }
    }
}