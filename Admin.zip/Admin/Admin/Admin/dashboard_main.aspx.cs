﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class dashboard_main : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            GetTotalCustomers();
            GetTotalOrder();
            GetTotalProduct();
            GetTotalamount();
        }
        public void GetTotalCustomers()
        {

            int totalCustomers = 0;

            SqlCommand cmd = new SqlCommand("SELECT count(id) FROM tblUser", connectionString);

            connectionString.Open();
            object result = cmd.ExecuteScalar();

            if (result != DBNull.Value)
            {
                totalCustomers = Convert.ToInt32(result);
            }
            else
            {
                totalCustomers = 0;
            }

            Label1.Text = totalCustomers.ToString();


            connectionString.Close();

        }

        public void GetTotalOrder()
        {

            int totalOrder = 0;

            SqlCommand cmd = new SqlCommand("SELECT count(order_id) FROM tblOrder", connectionString);

            connectionString.Open();
            object result = cmd.ExecuteScalar();

            if (result != DBNull.Value)
            {
                totalOrder = Convert.ToInt32(result);
            }
            else
            {
                totalOrder = 0;
            }

            Label2.Text = totalOrder.ToString();


            connectionString.Close();

        }


        public void GetTotalamount()
        {

            int totalOrder = 0;

            SqlCommand cmd = new SqlCommand("SELECT count(order_id) FROM tblOrder", connectionString);

            connectionString.Open();
            object result = cmd.ExecuteScalar();

            if (result != DBNull.Value)
            {
                totalOrder = Convert.ToInt32(result);
            }
            else
            {
                totalOrder = 0;
            }

            Label3.Text = totalOrder.ToString();


            connectionString.Close();

        }

        public void GetTotalProduct()
        {

            int totalproduct = 0;

            SqlCommand cmd = new SqlCommand("SELECT count(pid) FROM tblProduct", connectionString);

            connectionString.Open();
            object result = cmd.ExecuteScalar();

            if (result != DBNull.Value)
            {
                totalproduct = Convert.ToInt32(result);
            }
            else
            {
                totalproduct = 0;
            }

            Label4.Text = totalproduct.ToString();


            connectionString.Close();

        }
    }

}