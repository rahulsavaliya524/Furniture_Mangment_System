﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class order : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["adminlogin"] == null)
            {
                Response.Redirect("Login_admin.aspx");
            }
            if (!IsPostBack)
            {
              
                BindGridView();
            }
        }

        private void BindGridView()
        {
            using (connectionString)
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM tblOrder", connectionString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }

        //protected void Unnamed1_Click(object sender, EventArgs e)
        //{
        //    string searchTerm = TextBox1.Text;
        //    string commandText = "SELECT * FROM tblCategorys WHERE cname LIKE '%' + @SearchTerm + '%'";
        //    SqlCommand command = new SqlCommand(commandText, connectionString);
        //    command.Parameters.AddWithValue("@SearchTerm", searchTerm);

        //    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
        //    DataTable dataTable = new DataTable();
        //    dataAdapter.Fill(dataTable);

        //    GridView1.DataSource = dataTable;
        //    GridView1.DataBind();
        //}


    }
}