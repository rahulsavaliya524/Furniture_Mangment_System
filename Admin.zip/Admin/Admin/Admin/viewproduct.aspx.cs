﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class viewproduct : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["adminlogin"] == null)
            {
                Response.Redirect("Login_admin.aspx");
            }
            if (!IsPostBack)
            {
                HyperLinkField editColumn = new HyperLinkField();
                HyperLinkField deleteColumn = new HyperLinkField();
                deleteColumn.HeaderText = "Edit";
                deleteColumn.Text = "Edit";
                deleteColumn.DataNavigateUrlFormatString = "~/UpdateProduct.aspx?id={0}";
                deleteColumn.DataNavigateUrlFields = new string[] { "pid" };

                editColumn.HeaderText = "Delete";
                editColumn.Text = "Delete";
                editColumn.DataNavigateUrlFormatString = "~/delete_product.aspx?id={0}";
                editColumn.DataNavigateUrlFields = new string[] { "pid" };

                GridView1.Columns.Add(editColumn);
                GridView1.Columns.Add(deleteColumn);
                BindGridView();
            }

        }

        //protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    GridView1.PageIndex = e.NewPageIndex;
        //    BindGridView(); // call the method that binds data to the GridView control
        //}

        private void BindGridView()
        {
            using (connectionString)
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM tblProduct", connectionString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }
        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            string searchTerm = TextBox1.Text;
            string commandText = "SELECT * FROM tblProduct WHERE pname LIKE '%' + @SearchTerm + '%'";
            SqlCommand command = new SqlCommand(commandText, connectionString);
            command.Parameters.AddWithValue("@SearchTerm", searchTerm);

            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);

            GridView1.DataSource = dataTable;
            GridView1.DataBind();
        }
    }
        
 }