﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class insert_category : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["adminlogin"] == null)
            {
                Response.Redirect("Login_admin.aspx");
            }
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            if (categoryname.Text != null)
            {
                //String ins = "Insert into tblCategory(cname) values('" + categoryname.Text + "')";
                //SqlCommand cmd = new SqlCommand(ins, con);
                //con.Open();

                //cmd.ExecuteNonQuery();

                //con.Close();



                string name = categoryname.Text;

                string fileName = Path.GetFileName(cimage.FileName);
                string fileExtension = Path.GetExtension(fileName);
                string uniqueFileName = Guid.NewGuid().ToString() + fileExtension;
                string uploadDirectory = Server.MapPath("~/ProductImages/");
                string uploadDirectory_view = @"C:\Users\rahul\source\repos\romit\romit\database_picture\";



                cimage.SaveAs(uploadDirectory + uniqueFileName);
                cimage.SaveAs(uploadDirectory_view + uniqueFileName);
                string filePath = "ProductImages/" + uniqueFileName;
                string filePath_view = "database_picture/" + uniqueFileName;

                string query = "Insert into tblCategorys(cname,cimage,vimage) values(@title,@image1,@image2)";
                SqlCommand cmd = new SqlCommand(query, con);

                //Set the parameters for the command object
                cmd.Parameters.AddWithValue("@title", name);
                cmd.Parameters.AddWithValue("@image1", filePath);
                cmd.Parameters.AddWithValue("@image2", filePath_view);


                con.Open();

                cmd.ExecuteNonQuery();

                con.Close();
                Response.Redirect("viewcategory.aspx");

            }
        }
    }
}