﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class UpdateCategory : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                if (Request.QueryString["id"] != null)
                {
                    int id = int.Parse(Request.QueryString["id"]);
                    string query = "SELECT * FROM tblCategorys WHERE cid=@Category_id";

                    using (connectionString)
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(query, connectionString))
                        {
                            adapter.SelectCommand.Parameters.AddWithValue("@Category_id", id);
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            if (dt.Rows.Count > 0)
                            {

                                categoryname.Text = dt.Rows[0]["cname"].ToString();

                                string imagePath = dt.Rows[0]["vimage"].ToString();
                                if (!string.IsNullOrEmpty(imagePath))
                                {
                                    cimage.Attributes["value"] = imagePath;
                                }
                                //fileProduct.Attributes.Add("value", "hello");
                                

                            }
                        }
                    }
                }
            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int id = int.Parse(Request.QueryString["id"]);

            string name = categoryname.Text;

            string fileName = Path.GetFileName(cimage.FileName);
            string fileExtension = Path.GetExtension(fileName);
            string uniqueFileName = Guid.NewGuid().ToString() + fileExtension;
            //string uploadDirectory = Server.MapPath("~/ProductImages/");

            //cimage.SaveAs(uploadDirectory + uniqueFileName);

            //string filePath = "ProductImages/" + uniqueFileName;
            string uploadDirectory = Server.MapPath("~/ProductImages/");
            string uploadDirectory_view = @"C:\Users\rahul\source\repos\romit\romit\database_picture\";



            cimage.SaveAs(uploadDirectory + uniqueFileName);
            cimage.SaveAs(uploadDirectory_view + uniqueFileName);
            string filePath = "ProductImages/" + uniqueFileName;
            string filePath_view = "database_picture/" + uniqueFileName;

            string query = "UPDATE tblCategorys SET cname = @name,cimage=@image, vimage=@vimage WHERE cid = @id";
            SqlCommand cmd = new SqlCommand(query, connectionString);

            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@image",filePath);
            cmd.Parameters.AddWithValue("@vimage", filePath_view);
            cmd.Parameters.AddWithValue("@id", id);

            connectionString.Open();
            cmd.ExecuteNonQuery();
            connectionString.Close();

            Response.Redirect("viewcategory.aspx");

        }
    }
}