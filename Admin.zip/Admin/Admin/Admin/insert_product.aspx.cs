﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class insert_product : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["adminlogin"] == null)
            {
                Response.Redirect("Login_admin.aspx");
            }
            if (!IsPostBack)
            {

                PopulateBrandList();

            }
           

        }

        private void PopulateBrandList()
        {
            string query = "SELECT * FROM tblCategorys";
            SqlCommand cmd = new SqlCommand(query, connectionString);
            connectionString.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListItem item = new ListItem();
                item.Text = reader["cname"].ToString();
                item.Value = reader["cid"].ToString();
                category.Items.Add(item);
            }
            reader.Close();
            connectionString.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = pnametxt.Text;
            int categoryid = int.Parse(category.SelectedValue);
            int qty = int.Parse(product_quantity.Text);
            int price = int.Parse(product_price.Text);
            string desc = pdesctxt.Text;



            string fileName = Path.GetFileName(product_imgupload.FileName);
            string fileExtension = Path.GetExtension(fileName);
            string uniqueFileName = Guid.NewGuid().ToString() + fileExtension;
            string uploadDirectory = Server.MapPath("~/ProductImages/");
            string uploadDirectory_view = @"C:\Users\rahul\source\repos\romit\romit\database_picture\";

            product_imgupload.SaveAs(uploadDirectory + uniqueFileName);
            product_imgupload.SaveAs(uploadDirectory_view + uniqueFileName);

            string filePath = "ProductImages/" + uniqueFileName;
            string filePath_view = "database_picture/" + uniqueFileName;


            string query = "INSERT INTO tblProduct( pname, disc, pimage,vimage, price, quantity, cid) VALUES(@title, @description, @image1,@image2, @quantity, @price ,@category)";
            SqlCommand cmd = new SqlCommand(query, connectionString);

            //Set the parameters for the command object
            cmd.Parameters.AddWithValue("@title", name);
            cmd.Parameters.AddWithValue("@description", desc);
            cmd.Parameters.AddWithValue("@category", categoryid);
            cmd.Parameters.AddWithValue("@image1", filePath);
            cmd.Parameters.AddWithValue("@image2", filePath_view);
            cmd.Parameters.AddWithValue("@quantity", qty);
            cmd.Parameters.AddWithValue("@price", price);

            connectionString.Open();

            cmd.ExecuteNonQuery();

            connectionString.Close();

            Response.Redirect("viewproduct.aspx");


        }

    }

}