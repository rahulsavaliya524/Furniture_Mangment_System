﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class Login_admin : System.Web.UI.Page
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            connectionString.Open();
            string query = "select * from Admin where username='" + username.Text + "' and password='" + password.Text + "'";
            SqlCommand cmd = new SqlCommand(query, connectionString);
            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr.Read())
            {
                Session["adminlogin"] = username.Text;

                Response.Redirect("insert_category.aspx");

            }
            else
            {
                error.Text = "Invalid Username or Password.";
            }
            connectionString.Close();
        }
    }
}