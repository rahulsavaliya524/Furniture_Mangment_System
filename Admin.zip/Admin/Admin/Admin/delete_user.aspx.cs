﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class delete_user : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int id = int.Parse(Request.QueryString["id"]);
            string query = "DELETE FROM tblUser WHERE id=@Category_id";

            using (SqlConnection connectionString = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True"))
            {
                using (SqlCommand cmd = new SqlCommand(query, connectionString))
                {
                    cmd.Parameters.AddWithValue("@Category_id", id);
                    connectionString.Open();
                    cmd.ExecuteNonQuery();
                    connectionString.Close();
                }
            }

            Response.Redirect("view_user.aspx");
        }
    }
}