﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class view_user : System.Web.UI.Page
    {
        SqlConnection connectionstring = new SqlConnection(@"Data Source=hp\SQLEXPRESS;Initial Catalog=main_furniture;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["adminlogin"] == null)
            {
                Response.Redirect("Login_admin.aspx");
            }
            HyperLinkField deleteColumn = new HyperLinkField();
            deleteColumn.HeaderText = "Delete";
            deleteColumn.Text = "Delete";
            deleteColumn.DataNavigateUrlFormatString = "~/delete_user.aspx?id={0}";
            deleteColumn.DataNavigateUrlFields = new string[] { "id" };
            deleteColumn.ItemStyle.CssClass = "delete-link";

         
            GridView1.Columns.Add(deleteColumn);

            BindGridView();
        }
        private void BindGridView()
        {
            using (connectionstring)
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM tblUser", connectionstring))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
            connectionstring.Close();

        }

        protected void buttonsearch_Click(object sender, EventArgs e)
        {
            //string searchTerm = TextBox1.Text;
            //string commandText = "SELECT * FROM tblUser WHERE name LIKE '%' + @SearchTerm + '%'";
            //SqlCommand command = new SqlCommand(commandText, connectionstring);
            //command.Parameters.AddWithValue("@SearchTerm", searchTerm);

            //SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            //DataTable dataTable = new DataTable();
            //dataAdapter.Fill(dataTable);

            //GridView1.DataSource = dataTable;
            //GridView1.DataBind();
        }
    }
    
}